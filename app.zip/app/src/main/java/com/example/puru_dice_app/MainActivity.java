package com.example.puru_dice_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button instruction_noob = (Button)findViewById(R.id.button7);
        Button rollbutton = (Button)findViewById(R.id.roll_button);
        Button exitbutton = (Button)findViewById(R.id.button_exit);
        final ImageView left_dice = (ImageView)findViewById(R.id.image_leftdice);
       final ImageView right_dice = (ImageView)findViewById(R.id.image_rightdice);
       final int[] numbers_dice = {R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6};
       exitbutton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               finish();
           }
       });
       instruction_noob.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               navigate();
           }
       });
        rollbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("Dice","The Button has been pressed");
                Random generate = new Random();
                int store_num = generate.nextInt(6);  //Generates random no. between 0 to 6
                Log.d("Number_Random","Random number is generated"+store_num);
                left_dice.setImageResource(numbers_dice[store_num]);
                store_num = generate.nextInt(6);
                right_dice.setImageResource(numbers_dice[store_num]);
                showmessage_1();
            }
        });
    }
    public void showmessage_1(){
        Toast.makeText(this, " The Dice has been rolled successfully. ", Toast.LENGTH_SHORT).show();
    }
    public void navigate(){
        Intent nav = new Intent(this,Main2Activity.class);
        startActivity(nav);
    }
}
