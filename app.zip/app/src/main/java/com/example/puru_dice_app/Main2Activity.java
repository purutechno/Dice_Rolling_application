package com.example.puru_dice_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ImageView back_nav = (ImageView)findViewById(R.id.image_backbutton);
        Button rate_the_app = (Button)findViewById(R.id.button_rate);
        back_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigate_home();
                finish();
            }
        });
        rate_the_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                go_to_rating();
                finish();
            }
        });
    }
    public void navigate_home(){
        Intent nav = new Intent(this, MainActivity.class);
        startActivity(nav);
        finish();
    }
    public void go_to_rating(){
        Intent go_to = new Intent(this , Main3Activity.class);
        startActivity(go_to);
    }
}
