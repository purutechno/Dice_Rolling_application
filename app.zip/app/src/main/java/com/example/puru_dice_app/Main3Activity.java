package com.example.puru_dice_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

    }
    public void rate_it(View v){
        RatingBar ratingBar = (RatingBar)findViewById(R.id.ratingBar);
        float rating = ratingBar.getRating();
        Toast.makeText(getApplicationContext(), "You rated us "+rating+" Star", Toast.LENGTH_SHORT).show();
        Intent go_back_to_main = new Intent(this, MainActivity.class);
        startActivity(go_back_to_main);
        finish();
    }
}
